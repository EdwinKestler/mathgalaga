package com.robocrops.mathgalaga

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.view.MotionEvent
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

class BaseSystem(private val controller: GameController) {
    open fun update() {}
}

class InputSystem(controller: GameController) : BaseSystem(controller) {
    override fun update() {
        // Handled in onTouchEvent
    }
}

class MovementSystem(controller: GameController) : BaseSystem(controller) {
    override fun update() {
        // Alien movement
        controller.world["alien_movement"]?.forEach { (eid, amAny) ->
            val am = amAny as Map<String, Any>
            var (x, y) = controller.world["position"]!![eid] as Pair<Float, Float>
            val size = controller.world["size"]!![eid] as Pair<Int, Int>
            x += (am["speed"] as Int) * (am["direction"] as Int)
            if (x < 0 || x + size.first > Config.ScreenSettings.WIDTH) {
                am["direction"] = (am["direction"] as Int) * -1
                y += 20
            }
            controller.world["position"]!![eid] = Pair(x, y)
        }
        // Velocity-based (bullets)
        controller.world["velocity"]?.forEach { (eid, velAny) ->
            val vel = velAny as Pair<Int, Int>
            var (x, y) = controller.world["position"]!![eid] as Pair<Float, Float>
            x += vel.first
            y += vel.second
            controller.world["position"]!![eid] = Pair(x, y)
        }
    }
}

class ShootingSystem(controller: GameController) : BaseSystem(controller) {
    override fun update() {
        val now = System.currentTimeMillis()
        controller.world["shooter"]?.forEach { (eid, sAny) ->
            val s = sAny as MutableMap<String, Any>
            if (s["chance"] != null) {
                // Alien shooting
                if (Random.nextFloat() < (s["chance"] as Double) && now - (s["last_shot"] as Long) > (s["interval"] as Long)) {
                    controller.createBullet(eid, s["bullet_speed"] as Int)
                    s["last_shot"] = now
                }
            } else {
                // Player shooting: Handled in touch
            }
        }
    }
}

class CollisionSystem(controller: GameController) : BaseSystem(controller) {
    override fun update() {
        val hits = mutableListOf<Pair<Int, Int>>()
        val bulletEids = controller.world["bullet"]?.keys?.toList() ?: emptyList()
        val alienEids = controller.world["alien"]?.keys?.toList() ?: emptyList()
        bulletEids.forEach { bEid ->
            val bRect = controller.getRect(bEid)
            var hit = false
            alienEids.forEach { aEid ->
                if (controller.world["explosion"]?.containsKey(aEid) == true) return@forEach
                val aRect = controller.getRect(aEid)
                if (bRect.intersect(aRect)) {
                    hits.add(Pair(bEid, aEid))
                    hit = true
                    return@forEach
                }
            }
            if (hit) return@forEach
            controller.playerEids.forEach { pEid ->
                val p = controller.world["player"]!![pEid] as MutableMap<String, Any>
                if (p["state"] != "active") return@forEach
                val pRect = controller.getRect(pEid)
                if (bRect.intersect(pRect)) {
                    hits.add(Pair(bEid, pEid))
                    return@forEach
                }
            }
        }
        hits.forEach { (bEid, targetEid) ->
            val ownerEid = (controller.world["bullet"]!![bEid] as Map<String, Any>)["owner_eid"] as Int
            controller.removeEntity(bEid)
            if (controller.playerEids.contains(targetEid)) {
                // Alien bullet hit player
                if (controller.playerEids.contains(ownerEid)) return@forEach
                val p = controller.world["player"]!![targetEid] as MutableMap<String, Any>
                p["lives"] = (p["lives"] as Int) - 1
                controller.view.playHitSound()
                if (p["lives"] as Int > 0) {
                    p["state"] = "respawning"
                    p["respawn_time"] = System.currentTimeMillis()
                } else {
                    p["state"] = "dead"
                }
            } else {
                // Player bullet hit alien
                if (!controller.playerEids.contains(ownerEid)) return@forEach
                val playerEid = ownerEid
                val p = controller.world["player"]!![playerEid] as MutableMap<String, Any>
                val a = controller.world["alien"]!![targetEid] as Map<String, Any>
                var canKill = true
                if (a["number"] != null) {
                    if (a["number"] != p["problem"]!!["answer"] || p["cleared_top"] as Boolean) {
                        canKill = false
                    }
                }
                if (!canKill) return@forEach
                // Kill alien
                val now = System.currentTimeMillis()
                controller.world.getOrPut("explosion") { mutableMapOf() }[targetEid] = mapOf("start" to now)
                controller.world.getOrPut("lifespan") { mutableMapOf() }[targetEid] = mapOf("start" to now, "duration" to Config.ExplosionSettings.DURATION)
                controller.world["alien_movement"]?.remove(targetEid)
                controller.world["shooter"]?.remove(targetEid)
                controller.world["collider"]?.remove(targetEid)
                controller.world["render"]!![targetEid] = mapOf("type" to "explosion", "color" to Config.ColorSettings.YELLOW, "max_radius" to 30)
                controller.view.playExplosionSound()
                if (a["number"] == null) {
                    p["score"] = (p["score"] as Double) + 1.0
                } else {
                    p["cleared_top"] = true
                    p["streak"] = (p["streak"] as Int) + 1
                    val bonus = 1 + 0.1 * (p["streak"] as Int)
                    p["score"] = (p["score"] as Double) + bonus
                    val pos = controller.world["position"]!![targetEid] as Pair<Float, Float>
                    val comboEid = controller.newEntity()
                    controller.world["position"]!![comboEid] = pos
                    controller.world["render"]!![comboEid] = mapOf(
                        "type" to "combo_text",
                        "text" to "×${p["streak"]}",
                        "color" to Config.ColorSettings.YELLOW,
                        "font" to Config.FontSettings.COMBO
                    )
                    controller.world.getOrPut("lifespan") { mutableMapOf() }[comboEid] = mapOf("start" to now, "duration" to Config.ComboSettings.DURATION)
                    controller.world.getOrPut("float_up") { mutableMapOf() }[comboEid] = mapOf("speed" to Config.ComboSettings.FLOAT_SPEED)
                    (p["dm"] as DifficultyManager).record(true)
                }
            }
        }
    }
}

class LifespanSystem(controller: GameController) : BaseSystem(controller) {
    override fun update() {
        val now = System.currentTimeMillis()
        val toRemove = mutableListOf<Int>()
        controller.world["lifespan"]?.forEach { (eid, lAny) ->
            val l = lAny as Map<String, Long>
            if (now - l["start"]!! > l["duration"]!!) {
                toRemove.add(eid)
            }
        }
        toRemove.forEach { controller.removeEntity(it) }
        // Respawning
        controller.world["player"]?.forEach { (eid, pAny) ->
            val p = pAny as MutableMap<String, Any>
            if (p["state"] == "respawning" && now - (p["respawn_time"] as Long) > Config.PlayerSettings.RESPAWN_DURATION) {
                p["state"] = "active"
                controller.world["position"]!![eid] = Pair(p["start_x"] as Float, controller.world["position"]!![eid]!!.second as Float)
            }
        }
    }
}

class BoundsSystem(controller: GameController) : BaseSystem(controller) {
    override fun update() {
        val toRemove = mutableListOf<Int>()
        controller.world["bullet"]?.keys?.forEach { eid ->
            val y = controller.world["position"]!![eid]!!.second as Float
            val h = controller.world["size"]!![eid]!!.second as Int
            if (y < 0 || y + h > Config.ScreenSettings.HEIGHT) {
                toRemove.add(eid)
            }
        }
        toRemove.forEach { controller.removeEntity(it) }
    }
}

class RenderingSystem(controller: GameController) : BaseSystem(controller) {
    override fun update() {}

    fun draw(canvas: Canvas) {
        controller.world["render"]?.keys?.forEach { eid ->
            if (controller.playerEids.contains(eid) && (controller.world["player"]!![eid] as Map<String, Any>)["state"] == "dead") return@forEach
            val r = controller.world["render"]!![eid] as Map<String, Any>
            val pos = controller.world["position"]!![eid] as Pair<Float, Float>
            val size = controller.world["size"]?.get(eid) as? Pair<Int, Int> ?: Pair(0, 0)
            when (r["type"]) {
                "rect" -> {
                    val paint = Paint().apply { color = r["color"] as Int }
                    canvas.drawRect(controller.getRect(eid), paint)
                }
                "sprite" -> {
                    val image = r["image"] as Bitmap
                    canvas.drawBitmap(image, pos.first, pos.second, null)
                    (r["text"] as? String)?.let { text ->
                        val paint = Config.FontSettings.MAIN
                        val bounds = Rect()
                        paint.getTextBounds(text, 0, text.length, bounds)
                        val centerX = pos.first + size.first / 2 - bounds.width() / 2
                        val centerY = pos.second + size.second / 2 + bounds.height() / 2
                        canvas.drawText(text, centerX, centerY, paint)
                    }
                }
                "explosion" -> {
                    val elapsed = System.currentTimeMillis() - (controller.world["explosion"]!![eid] as Map<String, Long>)["start"]!!
                    val radius = ((elapsed.toFloat() / Config.ExplosionSettings.DURATION) * (r["max_radius"] as Int)).toInt()
                    val centerX = pos.first + size.first / 2
                    val centerY = pos.second + size.second / 2
                    val paint = Paint().apply { color = r["color"] as Int }
                    canvas.drawCircle(centerX, centerY, radius.toFloat(), paint)
                }
                "combo_text" -> {
                    val elapsed = System.currentTimeMillis() - (controller.world["lifespan"]!![eid] as Map<String, Long>)["start"]!!
                    val dur = (controller.world["lifespan"]!![eid] as Map<String, Long>)["duration"]!!
                    val alpha = (255 * (1 - elapsed.toFloat() / dur)).toInt()
                    val paint = r["font"] as Paint
                    paint.alpha = alpha
                    val ypos = pos.second - (elapsed.toFloat() / dur) * (controller.world["float_up"]!![eid] as Map<String, Int>)["speed"]!!.toFloat()
                    canvas.drawText(r["text"] as String, pos.first, ypos, paint)
                }
            }
        }
    }
}

abstract class BaseState(protected val controller: GameController) {
    open fun handleTouch(event: MotionEvent) {}
    open fun update() {}
    open fun draw(canvas: Canvas) {}
}

class PlayingState(controller: GameController) : BaseState(controller) {
    override fun handleTouch(event: MotionEvent) {
        // Touch handled in GameView and passed to controller
    }

    override fun update() {
        controller.inputSystem.update()
        controller.shootingSystem.update()
        controller.movementSystem.update()
        controller.collisionSystem.update()
        controller.lifespanSystem.update()
        controller.boundsSystem.update()

        // Level advance
        if (controller.playerEids.all { (controller.world["player"]!![it] as Map<String, Any>)["cleared_top"] as Boolean }) {
            controller.playerEids.forEach { eid ->
                val p = controller.world["player"]!![eid] as MutableMap<String, Any>
                p["cleared_top"] = false
                p["problem"] = generateAdaptiveProblem(p["dm"] as DifficultyManager)
            }
            controller.level++
            if (controller.level > Config.GameSettings.MAX_LEVEL) {
                controller.switchState("win")
            } else {
                controller.switchState("level_transition")
            }
        }

        // Check dead
        if (controller.playerEids.any { (controller.world["player"]!![it] as Map<String, Any>)["lives"] as Int <= 0 }) {
            controller.switchState("game_over")
        }
    }

    override fun draw(canvas: Canvas) {
        canvas.drawColor(Config.ColorSettings.BLACK)
        val paint = Paint().apply { color = Config.ColorSettings.WHITE }
        Config.starsPositions.forEach { (x, y) ->
            canvas.drawCircle(x.toFloat(), y.toFloat(), 1f, paint)
        }
        controller.renderingSystem.draw(canvas)
        // HUD
        controller.playerEids.forEachIndexed { i, eid ->
            val p = controller.world["player"]!![eid] as Map<String, Any>
            val x0 = if (i == 0) 10f else Config.ScreenSettings.WIDTH - 140f
            canvas.drawText((p["problem"] as Map<String, Any>)["question"] as String, x0, 10f, Config.FontSettings.MAIN)
            canvas.drawText("P${i+1} Score:${(p["score"] as Double).toInt()}", x0, 50f, Config.FontSettings.MAIN)
            canvas.drawText("P${i+1} Lives:${p["lives"]}", x0, 90f, Config.FontSettings.MAIN)
        }
        val lvlTxt = "Level:${controller.level}"
        val bounds = Rect()
        Config.FontSettings.MAIN.getTextBounds(lvlTxt, 0, lvlTxt.length, bounds)
        canvas.drawText(lvlTxt, (Config.ScreenSettings.WIDTH / 2 - bounds.width() / 2).toFloat(), 10f, Config.FontSettings.MAIN)
    }
}

class PausedState(controller: GameController) : BaseState(controller) {
    override fun update() {}

    override fun draw(canvas: Canvas) {
        controller.previousState?.draw(canvas)
        val text = "PAUSED"
        val paint = Config.FontSettings.MAIN
        paint.color = Config.ColorSettings.YELLOW
        val bounds = Rect()
        paint.getTextBounds(text, 0, text.length, bounds)
        canvas.drawText(text, (Config.ScreenSettings.WIDTH / 2 - bounds.width() / 2).toFloat(), (Config.ScreenSettings.HEIGHT / 2).toFloat(), paint)
    }
}

class LevelTransitionState(controller: GameController) : BaseState(controller) {
    private val startTime = System.currentTimeMillis()

    init {
        controller.setupLevel()
    }

    override fun update() {
        if (System.currentTimeMillis() - startTime > 2000) {
            controller.switchState("playing")
        }
    }

    override fun draw(canvas: Canvas) {
        canvas.drawColor(Config.ColorSettings.BLACK)
        val msg = "Level ${controller.level}! Good luck!"
        val paint = Config.FontSettings.MAIN
        val bounds = Rect()
        paint.getTextBounds(msg, 0, msg.length, bounds)
        canvas.drawText(msg, (Config.ScreenSettings.WIDTH / 2 - bounds.width() / 2).toFloat(), (Config.ScreenSettings.HEIGHT / 2 - bounds.height() / 2).toFloat(), paint)
    }
}

class GameOverState(controller: GameController) : BaseState(controller) {
    override fun update() {}

    override fun draw(canvas: Canvas) {
        canvas.drawColor(Config.ColorSettings.BLACK)
        val over = "Better luck next time"
        val instr = "Tap to retry or back to exit"
        val paint = Config.FontSettings.MAIN
        val boundsOver = Rect()
        paint.getTextBounds(over, 0, over.length, boundsOver)
        canvas.drawText(over, (Config.ScreenSettings.WIDTH / 2 - boundsOver.width() / 2).toFloat(), (Config.ScreenSettings.HEIGHT / 2 - 30).toFloat(), paint)
        val boundsInstr = Rect()
        paint.getTextBounds(instr, 0, instr.length, boundsInstr)
        canvas.drawText(instr, (Config.ScreenSettings.WIDTH / 2 - boundsInstr.width() / 2).toFloat(), (Config.ScreenSettings.HEIGHT / 2 + 10).toFloat(), paint)
    }
}

class WinState(controller: GameController) : BaseState(controller) {
    override fun update() {}

    override fun draw(canvas: Canvas) {
        canvas.drawColor(Config.ColorSettings.BLACK)
        val winMsg = "Congratulations! You Won!"
        val instr = "Tap to play again or back to exit"
        val paint = Config.FontSettings.MAIN
        val boundsWin = Rect()
        paint.getTextBounds(winMsg, 0, winMsg.length, boundsWin)
        canvas.drawText(winMsg, (Config.ScreenSettings.WIDTH / 2 - boundsWin.width() / 2).toFloat(), (Config.ScreenSettings.HEIGHT / 2 - 30).toFloat(), paint)
        val boundsInstr = Rect()
        paint.getTextBounds(instr, 0, instr.length, boundsInstr)
        canvas.drawText(instr, (Config.ScreenSettings.WIDTH / 2 - boundsInstr.width() / 2).toFloat(), (Config.ScreenSettings.HEIGHT / 2 + 10).toFloat(), paint)
    }
}

class GameController(val context: Context, val view: GameView) {
    var level = 1
    val world = mutableMapOf<String, MutableMap<Int, Any>>()
    private var nextEntityId = 0
    val playerEids = mutableListOf(newEntity(), newEntity())

    val inputSystem = InputSystem(this)
    val movementSystem = MovementSystem(this)
    val shootingSystem = ShootingSystem(this)
    val collisionSystem = CollisionSystem(this)
    val lifespanSystem = LifespanSystem(this)
    val boundsSystem = BoundsSystem(this)
    val renderingSystem = RenderingSystem(this)

    var previousState: BaseState? = null
    var currentState: BaseState = LevelTransitionState(this)

    private val states = mapOf(
        "playing" to ::PlayingState,
        "paused" to ::PausedState,
        "level_transition" to ::LevelTransitionState,
        "game_over" to ::GameOverState,
        "win" to ::WinState
    )

    var restart = false
    var exit = false

    init {
        Config.initSprites(context)
        Config.ScreenSettings.WIDTH = view.width
        Config.ScreenSettings.HEIGHT = view.height

        val dm1 = DifficultyManager()
        val dm2 = DifficultyManager()

        val colors = listOf(Config.ColorSettings.BLUE, Config.ColorSettings.RED)
        val startXs = listOf(100f, 600f)
        val sprites = listOf(Config.playerBlueSprite, Config.playerRedSprite)

        playerEids.forEachIndexed { i, eid ->
            val sprite = sprites[i]
            val size = Pair(sprite.width, sprite.height)
            world.getOrPut("position") { mutableMapOf() }[eid] = Pair(startXs[i], Config.ScreenSettings.HEIGHT - size.second - 10f)
            world.getOrPut("size") { mutableMapOf() }[eid] = size
            world.getOrPut("player") { mutableMapOf() }[eid] = mutableMapOf(
                "color" to colors[i],
                "dm" to (if (i == 0) dm1 else dm2),
                "lives" to Config.PlayerSettings.LIVES,
                "score" to 0.0,
                "problem" to generateAdaptiveProblem(if (i == 0) dm1 else dm2),
                "streak" to 0,
                "state" to "active",
                "respawn_time" to 0L,
                "cleared_top" to false,
                "start_x" to startXs[i]
            )
            world.getOrPut("player_movement") { mutableMapOf() }[eid] = mapOf("speed" to Config.PlayerSettings.SPEED)
            world.getOrPut("shooter") { mutableMapOf() }[eid] = mutableMapOf(
                "interval" to 500L,
                "last_shot" to 0L,
                "chance" to null,
                "bullet_speed" to Config.BulletSettings.PLAYER_SPEED
            )
            world.getOrPut("render") { mutableMapOf() }[eid] = mapOf(
                "type" to "sprite",
                "image" to sprite,
                "text" to null
            )
            world.getOrPut("collider") { mutableMapOf() }[eid] = true
        }
    }

    fun newEntity(): Int = nextEntityId++

    fun removeEntity(eid: Int) {
        world.values.forEach { it.remove(eid) }
    }

    fun switchState(stateName: String) {
        previousState = currentState
        currentState = states[stateName]!!.invoke(this)
    }

    fun getTopFormationPositions(level: Int): List<Pair<Float, Float>> {
        return when (level) {
            1 -> List(5) { Pair(100f + it * 120f, 50f) }
            2 -> List(5) { Pair(100f + it * 120f, 50f + if (it % 2 == 0) 50f else 0f) }
            // Add other levels as in original
            else -> List(5) { Pair(Random.nextFloat(50f, Config.ScreenSettings.WIDTH - 100f), Random.nextFloat(50f, 150f)) }
        }
    }

    fun getLowerFormationPositions(level: Int): List<Pair<Float, Float>> {
        val positions = mutableListOf<Pair<Float, Float>>()
        when (level) {
            1 -> for (i in 0..<5) for (j in 0..<2) positions.add(Pair(100f + i * 100f, 150f + j * 50f))
            // Add other levels as in original
            else -> for (i in 0..<8) for (j in 0..<3) positions.add(Pair(50f + i * 60f, 100f + j * 30f))
        }
        return positions
    }

    fun setupLevel() {
        // Remove non-player entities
        world["position"]?.keys?.filter { !playerEids.contains(it) }?.forEach { removeEntity(it) }

        val shape = Config.AlienSettings.SHAPE_TYPES[(level - 1) % Config.AlienSettings.SHAPE_TYPES.size]
        val speed = Config.AlienSettings.BASE_SPEED + (level - 1)
        val answers = playerEids.map { ((world["player"]!![it] as Map<String, Any>)["problem"] as Map<String, Any>)["answer"] as Int }
        val distractors = List(3) { Random.nextInt(1, 100) }
        val nums = (answers + distractors).shuffled()

        // Top aliens
        getTopFormationPositions(level).forEachIndexed { i, (x, y) ->
            val valNum = nums[i]
            val eid = newEntity()
            val image = Config.alienTopSprites[shape]!!
            world["position"]!![eid] = Pair(x, y)
            world["size"]!![eid] = Pair(image.width, image.height)
            world["render"]!![eid] = mapOf("type" to "sprite", "image" to image, "text" to valNum.toString())
            world.getOrPut("alien") { mutableMapOf() }[eid] = mapOf("number" to valNum, "shape" to shape)
            world.getOrPut("alien_movement") { mutableMapOf() }[eid] = mutableMapOf("speed" to speed, "direction" to 1)
            world.getOrPut("shooter") { mutableMapOf() }[eid] = mutableMapOf(
                "interval" to Config.AlienSettings.SHOOT_INTERVAL,
                "last_shot" to 0L,
                "chance" to Config.AlienSettings.SHOOT_CHANCE,
                "bullet_speed" to Config.BulletSettings.ALIEN_SPEED
            )
            world.getOrPut("collider") { mutableMapOf() }[eid] = true
        }

        // Lower aliens
        getLowerFormationPositions(level).forEach { (x, y) ->
            val eid = newEntity()
            val image = Config.alienLowerSprites[shape]!!
            world["position"]!![eid] = Pair(x, y)
            world["size"]!![eid] = Pair(image.width, image.height)
            world["render"]!![eid] = mapOf("type" to "sprite", "image" to image, "text" to null)
            world.getOrPut("alien") { mutableMapOf() }[eid] = mapOf("number" to null, "shape" to shape)
            world.getOrPut("alien_movement") { mutableMapOf() }[eid] = mutableMapOf("speed" to speed, "direction" to 1)
            world.getOrPut("shooter") { mutableMapOf() }[eid] = mutableMapOf(
                "interval" to Config.AlienSettings.SHOOT_INTERVAL,
                "last_shot" to 0L,
                "chance" to Config.AlienSettings.SHOOT_CHANCE,
                "bullet_speed" to Config.BulletSettings.ALIEN_SPEED
            )
            world.getOrPut("collider") { mutableMapOf() }[eid] = true
        }
    }

    fun getRect(eid: Int): Rect {
        val (x, y) = world["position"]!![eid] as Pair<Float, Float>
        val (w, h) = world["size"]!![eid] as Pair<Int, Int>
        return Rect(x.toInt(), y.toInt(), x.toInt() + w, y.toInt() + h)
    }

    fun createBullet(shooterEid: Int, speed: Int) {
        val (posX, posY) = world["position"]!![shooterEid] as Pair<Float, Float>
        val size = world["size"]!![shooterEid] as Pair<Int, Int>
        val bx = posX + size.first / 2 - Config.BulletSettings.WIDTH / 2
        val by = if (speed < 0) posY - Config.BulletSettings.HEIGHT else posY + size.second
        val eid = newEntity()
        world["position"]!![eid] = Pair(bx, by)
        world["size"]!![eid] = Pair(Config.BulletSettings.WIDTH, Config.BulletSettings.HEIGHT)
        world.getOrPut("velocity") { mutableMapOf() }[eid] = Pair(0, speed)
        world["render"]!![eid] = mapOf("type" to "rect", "color" to Config.ColorSettings.WHITE)
        world.getOrPut("bullet") { mutableMapOf() }[eid] = mapOf("owner_eid" to shooterEid)
        world["collider"]!![eid] = true
    }

    fun update() {
        currentState.update()
    }

    fun draw(canvas: Canvas) {
        currentState.draw(canvas)
    }

    fun handleTouch(event: MotionEvent) {
        when (event.action) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                val mid = Config.ScreenSettings.WIDTH / 2f
                val eid = if (event.x < mid) playerEids[0] else playerEids[1]
                val p = world["player"]!![eid] as Map<String, Any>
                if (p["state"] != "active") return
                val speed = (world["player_movement"]!![eid] as Map<String, Int>)["speed"]!!
                var (x, y) = world["position"]!![eid] as Pair<Float, Float>
                val size = world["size"]!![eid] as Pair<Int, Int>
                x = event.x - size.first / 2f
                x = max(0f, min(x, Config.ScreenSettings.WIDTH - size.first.toFloat()))
                world["position"]!![eid] = Pair(x, y)
                // Shoot on tap (if above player y)
                val s = world["shooter"]!![eid] as MutableMap<String, Any>
                val now = System.currentTimeMillis()
                if (event.y < y && now - (s["last_shot"] as Long) > (s["interval"] as Long)) {
                    createBullet(eid, s["bullet_speed"] as Int)
                    s["last_shot"] = now
                    view.playShootSound()
                }
            }
        }
        currentState.handleTouch(event)
        if (currentState is GameOverState || currentState is WinState) {
            if (event.action == MotionEvent.ACTION_DOWN) {
                // Restart on tap
                view.pause()
                MainActivity().finish() // Restart activity or reset
            }
        }
    }
}