package com.robocrops.mathgalaga

import kotlin.random.Random
import java.util.ArrayDeque

class DifficultyManager {
    private val window = ArrayDeque<Boolean>(Config.DifficultySettings.WINDOW)
    var level = 1

    fun record(correct: Boolean) {
        window.add(correct)
        if (window.size == Config.DifficultySettings.WINDOW) {
            val acc = window.count { it }.toFloat() / window.size
            if (acc > 0.8f && level < Config.DifficultySettings.LEVELS.size) level++
            else if (acc < 0.5f && level > 1) level--
        }
    }

    fun bounds(): Pair<Int, Int> = Config.DifficultySettings.LEVELS[level]!!
}

fun generateAdaptiveProblem(dm: DifficultyManager): Map<String, Any> {
    val (lo, hi) = dm.bounds()
    val a = Random.nextInt(lo, hi + 1)
    val b = Random.nextInt(lo, hi + 1)
    return mapOf("question" to "$a×$b", "answer" to a * b)
}