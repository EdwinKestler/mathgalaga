package com.robocrops.mathgalaga

import android.graphics.Rect

fun collides(r1: Rect, r2: Rect): Boolean = r1.intersect(r2)