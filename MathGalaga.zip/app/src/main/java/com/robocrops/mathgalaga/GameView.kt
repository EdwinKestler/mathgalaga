package com.robocrops.mathgalaga

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Typeface
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.SoundPool
import android.os.Build
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import kotlin.math.abs
import kotlin.random.Random

class GameView(context: Context) : SurfaceView(context), SurfaceHolder.Callback, Runnable {
    private var thread: Thread? = null
    private var running = false
    private val controller = GameController(context, this)

    // Sounds
    private lateinit var soundPool: SoundPool
    private var shootSoundId: Int = 0
    private var hitSoundId: Int = 0
    private var explosionSoundId: Int = 0

    init {
        holder.addCallback(this)
        initSounds()
    }

    private fun initSounds() {
        val maxStreams = 5
        soundPool = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            val audioAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            SoundPool.Builder()
                .setMaxStreams(maxStreams)
                .setAudioAttributes(audioAttributes)
                .build()
        } else {
            SoundPool(maxStreams, AudioManager.STREAM_MUSIC, 0)
        }
        shootSoundId = soundPool.load(context, R.raw.shoot, 1)
        hitSoundId = soundPool.load(context, R.raw.hit, 1)
        explosionSoundId = soundPool.load(context, R.raw.explosion, 1)
    }

    fun playShootSound() = soundPool.play(shootSoundId, 1f, 1f, 1, 0, 1f)
    fun playHitSound() = soundPool.play(hitSoundId, 1f, 1f, 1, 0, 1f)
    fun playExplosionSound() = soundPool.play(explosionSoundId, 1f, 1f, 1, 0, 1f)

    override fun surfaceCreated(holder: SurfaceHolder) {
        startGame()
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        // Handle screen size change if needed
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        pause()
    }

    private fun startGame() {
        running = true
        thread = Thread(this)
        thread?.start()
    }

    fun pause() {
        running = false
        thread?.join()
    }

    fun resume() {
        startGame()
    }

    override fun run() {
        while (running) {
            if (!holder.surface.isValid) continue
            val canvas = holder.lockCanvas()
            if (canvas != null) {
                synchronized(holder) {
                    controller.update()
                    controller.draw(canvas)
                }
                holder.unlockCanvasAndPost(canvas)
            }
            try {
                Thread.sleep(16) // ~60 FPS
            } catch (e: InterruptedException) {
                // Ignore
            }
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        controller.handleTouch(event)
        return true
    }
}