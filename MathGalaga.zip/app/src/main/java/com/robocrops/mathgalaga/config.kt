package com.robocrops.mathgalaga

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import kotlin.random.Random

object Config {
    object ScreenSettings {
        var WIDTH = 800
        var HEIGHT = 600
    }

    object FontSettings {
        val MAIN = Paint().apply {
            textSize = 30f
            color = Color.WHITE
            typeface = Typeface.DEFAULT
        }
        val COMBO = Paint().apply {
            textSize = 24f
            color = Color.WHITE
            typeface = Typeface.DEFAULT_BOLD
        }
    }

    object ColorSettings {
        val WHITE = Color.WHITE
        val BLACK = Color.BLACK
        val YELLOW = Color.YELLOW
        val GREEN = Color.GREEN
        val RED = Color.RED
        val BLUE = Color.BLUE
    }

    object PlayerSettings {
        const val WIDTH = 32
        const val HEIGHT = 32
        const val SPEED = 5
        const val LIVES = 3
        const val RESPAWN_DURATION = 1000L // ms
    }

    object AlienSettings {
        const val TOP_SIZE = 40
        const val LOWER_SIZE = 20
        const val BASE_SPEED = 2
        const val SHOOT_INTERVAL = 2000L // ms
        const val SHOOT_CHANCE = 0.005 // per frame
        val SHAPE_TYPES = listOf("square", "triangle", "circle")
    }

    object BulletSettings {
        const val WIDTH = 5
        const val HEIGHT = 10
        const val PLAYER_SPEED = -5
        const val ALIEN_SPEED = 5
    }

    object ComboSettings {
        const val DURATION = 1000L // ms
        const val FLOAT_SPEED = 15 // px total
    }

    object DifficultySettings {
        const val WINDOW = 10
        val LEVELS = mapOf(
            1 to (1 to 5),
            2 to (1 to 10),
            3 to (1 to 20),
            4 to (1 to 50),
            5 to (5 to 50)
        )
    }

    object ExplosionSettings {
        const val DURATION = 500L // ms
    }

    object BackgroundSettings {
        const val STARS_COUNT = 100
    }

    object GameSettings {
        const val MAX_LEVEL = 5
    }

    val starsPositions = List(BackgroundSettings.STARS_COUNT) {
        Pair(Random.nextInt(0, ScreenSettings.WIDTH), Random.nextInt(0, ScreenSettings.HEIGHT))
    }

    lateinit var playerBlueSprite: Bitmap
    lateinit var playerRedSprite: Bitmap
    val alienTopSprites = mutableMapOf<String, Bitmap>()
    val alienLowerSprites = mutableMapOf<String, Bitmap>()

    fun initSprites(context: Context) {
        playerBlueSprite = BitmapFactory.decodeResource(context.resources, R.drawable.player_blue)
        playerRedSprite = BitmapFactory.decodeResource(context.resources, R.drawable.player_red)

        AlienSettings.SHAPE_TYPES.forEach { shape ->
            alienTopSprites[shape] = BitmapFactory.decodeResource(
                context.resources,
                context.resources.getIdentifier("alien_${shape}_green", "drawable", context.packageName)
            )
            alienLowerSprites[shape] = BitmapFactory.decodeResource(
                context.resources,
                context.resources.getIdentifier("alien_${shape}_red", "drawable", context.packageName)
            )
        }
    }
}